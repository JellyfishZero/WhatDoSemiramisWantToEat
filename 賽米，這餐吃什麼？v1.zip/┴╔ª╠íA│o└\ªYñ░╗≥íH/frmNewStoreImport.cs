﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 賽米_這餐吃什麼_
{
    public partial class frmNewStoreImport : Form
    {
        /*資料庫連接字串*/
        string cnSemiramisMemory = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
            "AttachDbFilename=|DataDirectory|Semiramis_Memory.mdf;" +
            "Integrated Security=True";

        public frmNewStoreImport()
        {
            InitializeComponent();
        }

        private void NewStoreImport_Load(object sender, EventArgs e)
        {
            cmbSelectCase.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbDegree.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmMain f = (frmMain) this.Owner;
            f.setFalseFuctionWinowControl();
            this.Close();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            frmMain f = (frmMain)this.Owner;
            f.setFalseFuctionWinowControl();
            using (SqlConnection cn = new SqlConnection(cnSemiramisMemory))
            {
                //MessageBox.Show(cn.State.ToString());
                cn.Open();
                string caseL = cmbSelectCase.Text;
                string name = txtName.Text;
                int degree = int.Parse(cmbDegree.Text);

                if (name == "")
                {
                    f.dialogProcess(DialogSituation.DialogNewStoreImportNameEmpty);
                }
                else
                {
                    string checkStr = "Select COUNT(*) From Restaurant Where name = N'" + name + "'";
                    SqlCommand cmd1 = new SqlCommand(checkStr, cn);
                    SqlDataReader dr = cmd1.ExecuteReader();
                    dr.Read();
                    int flag = int.Parse(dr[0].ToString());
                    //MessageBox.Show(flag.ToString());
                    dr.Close();
                    if (flag<=0)
                    {
                        SqlCommand cmd2 = new SqlCommand("Insert Into Restaurant(caseL,name,degree) Values(N'" + caseL + "',N'" + name + "'," + degree + ")", cn);
                        cmd2.ExecuteNonQuery();
                        f.dialogProcess(DialogSituation.DialogNewStoreImportOK);
                    }
                    else
                    {
                        f.dialogProcess(DialogSituation.DialogNewStoreImportFailed);
                    }
                }
            }
            this.Close();
        }
    }
}

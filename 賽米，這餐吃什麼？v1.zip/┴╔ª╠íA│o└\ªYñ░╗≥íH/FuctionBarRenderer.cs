﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 賽米_這餐吃什麼_
{
    public class FuctionBarRenderer : ToolStripProfessionalRenderer
    {
        public FuctionBarRenderer() : base(new FuctionBarColors()) { }
    }

    public class FuctionBarColors : ProfessionalColorTable
    {
        //子項目被點選後的顏色
        public override Color MenuItemSelected
        {
            //回傳深藍色
            get { return Color.Gray; }
        }

        //子項目被點選後的漸層起始顏色
        public override Color MenuItemSelectedGradientBegin
        {
            get { return Color.Gray; }
        }

        //子項目被點選後的漸層結束顏色
        public override Color MenuItemSelectedGradientEnd
        {
            get { return Color.Gray; }
        }

        //子項目按下時的漸層起始顏色
        public override Color MenuItemPressedGradientBegin
        {
            get { return Color.Gray; }
        }

        //子項目按下時的漸層結束顏色
        public override Color MenuItemPressedGradientEnd
        {
            get { return Color.Gray; }
        }

        //MenuStrip父層漸層起始顏色
        public override Color MenuStripGradientBegin
        {
            get { return Color.Black; }
        }

        //MenuStrip父層漸層結束顏色
        public override Color MenuStripGradientEnd
        {
            get { return Color.Black; }
        }
    }
}

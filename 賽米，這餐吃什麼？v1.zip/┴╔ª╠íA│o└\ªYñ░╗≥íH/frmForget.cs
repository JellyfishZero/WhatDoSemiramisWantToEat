﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 賽米_這餐吃什麼_
{
    public partial class frmForget : Form
    {
        public frmForget()
        {
            InitializeComponent();
        }

        string cnSemiramisMemory = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
         "AttachDbFilename=|DataDirectory|Semiramis_Memory.mdf;" +
         "Integrated Security=True";

        private void frmForget_Load(object sender, EventArgs e)
        {
            cmbStoreName.DropDownStyle = ComboBoxStyle.DropDownList;
            importStoreName();
        }

        private void importStoreName()
        {
            using (SqlConnection cn = new SqlConnection(cnSemiramisMemory))
            {
                cn.Open();
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter("Select name from Restaurant", cn);
                da.Fill(ds, "resName");
                cmbStoreName.DataSource = ds.Tables["resName"];
                cmbStoreName.DisplayMember = "name";
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmMain f = (frmMain)this.Owner;
            f.setFalseFuctionWinowControl();
            this.Close();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            frmMain f = (frmMain)this.Owner;
            string target = cmbStoreName.Text;
            using (SqlConnection cn = new SqlConnection(cnSemiramisMemory))
            {
                cn.Open();
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("delete from Restaurant where name = N'" + target + "'", cn);
                cmd.ExecuteNonQuery();
            }
            f.setFalseFuctionWinowControl();
            f.dialogProcess(DialogSituation.DialogDeleteStore);
            this.Close();
        }
    }
}

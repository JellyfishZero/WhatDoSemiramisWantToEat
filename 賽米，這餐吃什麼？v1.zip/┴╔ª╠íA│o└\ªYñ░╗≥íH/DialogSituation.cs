﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 賽米_這餐吃什麼_
{
    public class DialogSituation
    {
        public static string DialogStart_0 = "DialogStart_0";
        public static string DialogDropDataBase_Yes = "DialogDropDataBase_Yes";
        public static string DialogDropDataBase_No = "DialogDropDataBase_No";
        public static string DialogNewStoreImportOK = "DialogNewStoreImportOK";
        public static string DialogNewStoreImportFailed = "DialogNewStoreImportFailed";
        public static string DialogNewStoreImportNameEmpty = "DialogNewStoreImportNameEmpty";
        public static string DialogDeleteStore = "DialogDeleteStore";
        public static string DialogUpdateStoreInformation = "DialogUpdateStoreInformation";
        public static string DialogSelectRestaurant_0 = "DialogSelectRestaurant_0";
        public static string DialogSelectRestaurant_1 = "DialogSelectRestaurant_1";
        public static string DialogSelectRestaurant_2 = "DialogSelectRestaurant_2";
        public static string DialogSelectRestaurant_makeSemiramisAngry = "DialogSelectRestaurant_makeSemiramisAngry";
        public static string DialogSelectRestaurantFailed = "DialogSelectRestaurantFailed";
        public static string DialogRelax_0 = "DialogRelax_0";
        public static string DialogRelax_1 = "DialogRelax_1";
    }
}

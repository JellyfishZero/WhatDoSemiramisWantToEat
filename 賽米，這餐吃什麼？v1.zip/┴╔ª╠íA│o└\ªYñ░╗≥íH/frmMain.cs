﻿/**
*********
**********
***********
************
*賽米我婆，天下第一。
************
***********
**********
*********
**/

/**        
 * This code was written by海蜇零        
 **/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace 賽米_這餐吃什麼_
{
    public partial class frmMain : Form
    {
        public frmMain() //啟動
        {   

            InitializeComponent();
        }

        /*視窗關閉的狀況*/
        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        /*子視窗控制*/
        bool fuctionWindowControl = false;

        /*賽米的表情*/
        List<string> Semiramis_Expressions = new List<string>();

        /*資料庫連接字串*/
        string cnSemiramisMemory = @"Data Source=(LocalDB)\MSSQLLocalDB;" + 
            "AttachDbFilename=|DataDirectory|Semiramis_Memory.mdf;" +
            "Integrated Security=True";

        /*狀況控制變數*/
        //int statusControl = 0;
        int repent = 0;

        private void frmMain_Load(object sender, EventArgs e)
        {
            /*上面Bar的顏色*/
            functionBar.Renderer = new FuctionBarRenderer();

            /*把圖片路徑字串加進去*/
            for (int i = 0; i < 13; i++)//依照賽米的表情編號，加入圖片字串到List裡
            {
                Semiramis_Expressions.Add(string.Format("Semiramis_Expressions\\{0}.png", i));
            };

            /*程式開頭的對話狀況*/
            dialogProcess(DialogSituation.DialogStart_0);

        }

        /*處理對話的函式*/
        public void dialogProcess(string situation)
        {
            string sqlstr = "select * from fuctionDialog where situation_no = '"+situation+"'";
            SqlDataAdapter getPossibleDialog = new SqlDataAdapter(sqlstr, cnSemiramisMemory);
            DataSet datasetDialog = new DataSet();
            getPossibleDialog.Fill(datasetDialog);
            Random r = new Random();
            int select = r.Next(0, datasetDialog.Tables[0].Rows.Count);
            int picNo = int.Parse(datasetDialog.Tables[0].Rows[select]["pictureNo"].ToString());
            string dialog = datasetDialog.Tables[0].Rows[select]["Dialog"].ToString();
            dialog = dialog.Replace("%n", "\n");

            if(imgSemiramis.Image != null)
            {
                imgSemiramis.Image.Dispose();
            }
            imgSemiramis.Image = null;
            imgSemiramis.Image = Image.FromFile(Semiramis_Expressions[picNo]);
            lblDialog.Text = dialog;
        }

        public void dialogProcess(string situation,string[] info)
        {
            string sqlstr = "select * from fuctionDialog where situation_no = '" + situation + "'";
            SqlDataAdapter getPossibleDialog = new SqlDataAdapter(sqlstr, cnSemiramisMemory);
            DataSet datasetDialog = new DataSet();
            getPossibleDialog.Fill(datasetDialog);
            Random r = new Random();
            int select = r.Next(0, datasetDialog.Tables[0].Rows.Count);
            int picNo = int.Parse(datasetDialog.Tables[0].Rows[select]["pictureNo"].ToString());
            string dialog = datasetDialog.Tables[0].Rows[select]["Dialog"].ToString();
            dialog = dialog.Replace("%n", "\n");
            dialog = dialog.Replace("%storeName", info[0]);

            if (imgSemiramis.Image != null)
            {
                imgSemiramis.Image.Dispose();
            }
            imgSemiramis.Image = null;
            imgSemiramis.Image = Image.FromFile(Semiramis_Expressions[picNo]);
            lblDialog.Text = dialog;
        }

        private void 忘卻所有一切ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("確定要忘掉所有已被記得的店家嗎？", 
                "忘卻所有一切", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (r == DialogResult.Yes)
            {
                using (SqlConnection cn = new SqlConnection(cnSemiramisMemory))
                {
                    //MessageBox.Show(cn.State.ToString());
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("drop table if exists Restaurant", cn);
                    cmd.ExecuteNonQuery();
                    string createNew = "CREATE TABLE Restaurant  (" +
                        "    [Id]     INT           IDENTITY (1, 1) NOT NULL," +
                        "    [caseL]  NVARCHAR (4)  NULL," +
                        "    [name]   NVARCHAR (50) NULL," +
                        "    [degree] INT           NULL," +
                        "    PRIMARY KEY CLUSTERED ([Id] ASC)" +
                        ");";
                    SqlCommand cmd2 = new SqlCommand(createNew, cn);
                    cmd2.ExecuteNonQuery();
                }
                dialogProcess(DialogSituation.DialogDropDataBase_Yes);
            }
            else
            {
                dialogProcess(DialogSituation.DialogDropDataBase_No);
            }
        }

        public void setFalseFuctionWinowControl()
        {
            fuctionWindowControl = false;
        }

        private void 新增店家ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmNewStoreImport nsi = null;
            if (fuctionWindowControl == false)
            {
                nsi = new frmNewStoreImport();
                nsi.Owner = this;
                nsi.TopMost = true;
                nsi.Visible = true;
                fuctionWindowControl = true;
            }
        }

        private void 修改店家ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmModify m = null;
            if(fuctionWindowControl == false)
            {
                m = new frmModify();
                m.Owner = this;
                m.TopMost = true;
                m.Visible = true;
                fuctionWindowControl = true;
            }
        }

        private void 刪除店家ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmForget f = null;
            if (fuctionWindowControl == false)
            {
                f = new frmForget();
                f.Owner = this;
                f.TopMost = true;
                f.Visible = true;
                fuctionWindowControl = true;
            }
        }

        private void lblDialog_Click(object sender, EventArgs e)
        {
            repent += 1;
            if (repent < 10)
            {
                DateTime nowTime = DateTime.Now;
                DateTime t1 = Convert.ToDateTime("3:00");
                DateTime t2 = Convert.ToDateTime("9:00");
                DateTime t3 = Convert.ToDateTime("15:00");
                DateTime t4 = Convert.ToDateTime("21:00");

                string caseL;
                string[] info = new string[2];

                if (DateTime.Compare(nowTime, t1) > 0 && DateTime.Compare(nowTime, t2) < 0)
                {
                    caseL = "早餐";
                }
                else if (DateTime.Compare(nowTime, t2) > 0 && DateTime.Compare(nowTime, t3) < 0)
                {
                    caseL = "中餐";
                }
                else if (DateTime.Compare(nowTime, t3) > 0 && DateTime.Compare(nowTime, t4) < 0)
                {
                    caseL = "晚餐";
                }
                else
                {
                    caseL = "消夜";
                }

                info = getStoreNameAndDegree(caseL);
                if (info == null)
                {
                    dialogProcess(DialogSituation.DialogSelectRestaurantFailed);
                }
                else
                {
                    if (int.Parse(info[1]) <= 3)
                    {
                        dialogProcess(DialogSituation.DialogSelectRestaurant_0, info);
                    }
                    else if (int.Parse(info[1]) > 3 && int.Parse(info[1]) < 8)
                    {
                        dialogProcess(DialogSituation.DialogSelectRestaurant_1, info);
                    }
                    else
                    {
                        dialogProcess(DialogSituation.DialogSelectRestaurant_2, info);
                    }
                }
            }
            else
            {
                dialogProcess(DialogSituation.DialogSelectRestaurant_makeSemiramisAngry);
            }
        }

        private string[] getStoreNameAndDegree(string caseL)
        {
            Random r = new Random();
            string[] info = new string[2];
            int count;
            using (SqlConnection cn = new SqlConnection(cnSemiramisMemory))
            {
                cn.Open();
                string sqlstr = "select * from Restaurant where caseL = N'" + caseL + "'";
                SqlDataAdapter getPossibleRestaurant = new SqlDataAdapter(sqlstr, cnSemiramisMemory);
                DataSet RestaurantInfo = new DataSet();
                
                getPossibleRestaurant.Fill(RestaurantInfo, "Res");
                DataTable dt = RestaurantInfo.Tables["Res"];
                count = dt.Rows.Count;
                if(count == 0)
                {
                    return null;
                }
                int targetNum = r.Next(0, count);
                info[0] = dt.Rows[targetNum]["name"].ToString();
                info[1] = dt.Rows[targetNum]["degree"].ToString();
            }
            return info;
        }

        private void 令賽米消氣ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (repent >= 10) {
                dialogProcess(DialogSituation.DialogRelax_1);
            }
            else
            {
                dialogProcess(DialogSituation.DialogRelax_0);
            }
            repent = 0;
        }
    }
}

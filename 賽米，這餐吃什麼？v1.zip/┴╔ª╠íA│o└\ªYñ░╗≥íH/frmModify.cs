﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 賽米_這餐吃什麼_
{
    public partial class frmModify : Form
    {
        public frmModify()
        {
            InitializeComponent();
        }

        bool initcount = false;

        string cnSemiramisMemory = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
        "AttachDbFilename=|DataDirectory|Semiramis_Memory.mdf;" +
        "Integrated Security=True";

        private void frmModify_Load(object sender, EventArgs e)
        {
            cmbStoreName.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSelectCase.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbDegree.DropDownStyle = ComboBoxStyle.DropDownList;
            importStoreName();
        }

        private void importStoreName()
        {
            using (SqlConnection cn = new SqlConnection(cnSemiramisMemory))
            {
                cn.Open();
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter("Select * from Restaurant", cn);
                da.Fill(ds, "res");
                cmbStoreName.DataSource = ds.Tables["res"];
                cmbStoreName.DisplayMember = "name";



                //DataTable dt = ds.Tables["res"];
                //label4.Text = dt.Rows[0]["name"].ToString();
                //label5.Text = dt.Rows[0]["caseL"].ToString();
                //label6.Text = dt.Rows[0]["degree"].ToString();
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            frmMain f = (frmMain)this.Owner;

            using (SqlConnection cn = new SqlConnection(cnSemiramisMemory))
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("update Restaurant set caseL = N'" + cmbSelectCase.Text + "', degree = " + int.Parse(cmbDegree.Text) + " where name = N'" + cmbStoreName.Text + "'", cn);
                cmd.ExecuteNonQuery();
            }
            f.setFalseFuctionWinowControl();
            f.dialogProcess(DialogSituation.DialogUpdateStoreInformation);
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmMain f = (frmMain)this.Owner;
            f.setFalseFuctionWinowControl();
            this.Close();
        }

        private void cmbStoreName_TextChanged(object sender, EventArgs e)
        {
            string target = cmbStoreName.Text;
            if (initcount == false)
            {
                initcount = true;
            }
            else
            {
                //MessageBox.Show(target);
                using (SqlConnection cn = new SqlConnection(cnSemiramisMemory))
                {
                    cn.Open();
                    DataSet ds = new DataSet();
                    SqlDataAdapter da = new SqlDataAdapter("Select * from Restaurant where name = N'" + target + "'", cn);
                    da.Fill(ds, "res");

                    DataTable dt = ds.Tables["res"];
                    label5.Text = dt.Rows[0]["caseL"].ToString();
                    label6.Text = dt.Rows[0]["degree"].ToString();
                }
            }
        }
    }
}
